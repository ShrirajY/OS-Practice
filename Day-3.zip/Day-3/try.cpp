#include<iostream>
#include<vector>
#include<string.h>
#include "MainMemory.hpp"
// #include "BuffersAlgo.hpp"
#include "BufferHeader.hpp"
int main()
{
    Files f("First File");
    f.Write(strdup("Hello Shriraj"));
    bt.TableShow();
}