#ifndef _FILE_HPP
#define _FILE_HPP

#include "InodesFile.hpp"
#include "Buffer.hpp"

#include<iostream>

class Files{
    private:
        char *FileName;
        Inode *inode;
        BufVec bufvec;
    public:
        Files(char *_Name)
        {
            FileName=(char *)malloc(sizeof(char)*30);
            strcpy(FileName,_Name);
            inode=(Inode *)malloc(sizeof(inode));
            inode=IPool.AllocatInode();
        }

        void Write(char *space)
        {
            bufvec.write(space);
        }

        void show()
        {
            bufvec.show();
        }

        void showInode()
        {
            std::cout<<inode->inodeNo<<std::endl;
        }

        void showBufHead()
        {
            bufvec.ShowBufHeaders();
        }

        void clear()
        {
            bufvec.clear();
        }
};

#endif