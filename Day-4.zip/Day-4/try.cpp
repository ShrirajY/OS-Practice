#include<iostream>
#include "File.hpp"
#include <cstring>
int main()
{
    Files f(strdup("Shriraj Yamkanmardi"));
    f.Write(strdup("Shriraj Yamkanmardi\n"));
    f.show();
    f.clear();
    f.Write(strdup("Shriraj Yamkanmardi\n"));
    f.show();
    return 0;
}